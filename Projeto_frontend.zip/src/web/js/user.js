import 'regenerator-runtime/runtime';
import axios from 'axios';
const url = "http://localhost:3000/"

$("#btnGravar").click(async function () {

     
        var name= $("#txtName").val()
        var email= $("#txtEmail").val()
        var admin=$("#chkAdmin").prop('checked')
        var password= $("#txtSenha").val()  
        await axios.post(url + 'users', {
            name:name,
            email:email,
            admin:admin,
            password:password
        }).then(function (response) {
            alert("Usuario Gravado com sucesso");
            location.reload();
        }).catch(function (error) {
            alert("Erro durante a gravação");
        });
});
function refreshtable(){
    var table2= new DataTable("#tbUsers");   
    table2.destroy();
    $('#tbUsers').empty();
}

$("#btnCancelar").click(async function () {
    try {
        $("#chkAdmin").prop('checked', false);
        $("#txtName").val('')
        $("#txtEmail").val('')
        $("#txtSenha").val('')
    } catch (errors) {
        alert(errors)
    }
});





$(document).ready(function () {
    loadTable();
})



function loadTable() {


    axios.get(url + 'users', {
    }).then(function (response) {

        
        let table= new DataTable('#tbUsers',{
            data: response.data,
            columns: [
                { data: 'id' },
                { data: 'name' },
                { data: 'email' }, 
                {
                    data: null,
                    defaultContent: '<button id="edit">Editar</button>&nbsp;<button id="excluir">Excluir</button>',
                    targets: -1
                },
               
            ]
        });

        table.on('click', 'button', function (e) {
            var data = table.row( $(this).parents('tr') ).data();
            if(this.id==='edit'){
                loadUser(data.id);
            } else{
                Excluir(data.id);
            }          
        });       

    }).catch(function (error) {
        alert(error);
    });
}

async function loadUser(id){
    await axios.get(url + 'users/' + id , {
    }).then(function (response) {
        $("#txtId").val( response.data.id)
        $("#txtName").val(  response.data.name)
        $("#txtEmail").val(  response.data.email)
        if(response.data.admin){
            admin= $("#chkAdmin").prop('checked:true')
        }
    }).catch(function (error) {
        console.log(error);
    });
}

async function  Excluir(id){
    await axios.delete(url + 'users/' + id , {
    }).then(function (response) {
        alert("Registro Excluido com Sucesso");
       location.reload();
    }).catch(function (error) {
        console.log(error);
    });
}