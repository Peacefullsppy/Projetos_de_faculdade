import 'regenerator-runtime/runtime';
import axios from 'axios';
const url = "http://localhost:3000/"

$("#btnLogin").click(async function () {
        var email= $("#txtEmail").val()
        var senha= $("#txtSenha").val()

        await axios.post(url + 'login', {
            email:email,
            password:senha
        }).then(function (response) {
            alert("Usuario Logado com sucesso")
        }).catch(function (error) {
            alert(error);
        });


});
$(document).ready(function () {
    alert("teste")
    loadTable();
})

function loadTable() {
    axios.get(url + 'users', {
    }).then(function (response) {
        let tb= new DataTable('#tbUsers',{
            data: response.data,
            columns: [
                { data: 'id' },
                { data: 'name' },
                { data: 'email' },                
            ]
        });
    }).catch(function (error) {
        alert(error);
    });
}

$("#btnCancelar").click(async function () {
    try {
        $("#txtEmail").val('')
        $("#txtSenha").val('')
    } catch (errors) {
        alert(errors)
    }
});