import { Router } from "express";
import { CreateUserController } from "./controller/user/CreateUserController";
import { ListUsersController } from "./controller/user/ListUserController";
import { UpdateUserController } from "./controller/user/UpdateUserController";
import { DeleteUserController } from "./controller/user/DeleteUserController";
import { CreateCategoryController } from "./controller/category/CreateCategoryConstroller";
import { ListCategoryController } from "./controller/category/ListCategoryController";
import { AuthenticateUserController } from "./controller/autentication/AutenticateUserController";
import { CreateProfileController } from "./controller/profile/CreateProfileController";
import {ListProfileController  } from "./controller/profile/ListProfileController";
const router = Router();
const createUserController  = new CreateUserController();
const listUsersController  = new ListUsersController();
const updateUserController  = new UpdateUserController();
const deleteUserController  = new DeleteUserController();
const createCategoryController  = new CreateCategoryController();
const listCategoryController  = new ListCategoryController();
const autenticateUserController  = new AuthenticateUserController();
const createProfileController = new CreateProfileController();
const listProfileController = new ListProfileController();

import { ensureAuthenticated} from "./middleware/ensureAutenticated";


router.post("/login", autenticateUserController.handle);
router.post("/users", createUserController.handle);
router.get("/users", listUsersController.handle);
router.post("/profiles", createProfileController.handle);
router.get("/profiles", listProfileController.handle);
router.put("/users/:id", updateUserController.handle);

router.get("/users/:id", listUsersController.findById);
router.delete("/users/:id", deleteUserController.handle);



router.use(ensureAuthenticated)

router.post("/category", createCategoryController.handle);
router.get("/category", listCategoryController.handle);

export {router} 