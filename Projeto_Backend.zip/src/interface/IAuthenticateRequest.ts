
interface IAuthenticateRequest {
    email: string;
    password: string;
}

export { IAuthenticateRequest }