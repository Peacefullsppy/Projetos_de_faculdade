interface IProfileRequest {
    id?: string;
    name: string;
  }

  export {IProfileRequest}